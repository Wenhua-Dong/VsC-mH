function [tD] = solve_tD(P, Y, Pi0, W, O, H, beta, gamma)

nv = length(Y);
tD = cell(1,nv);

for v = 1:nv
    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    WO = W*O{v};
    WOH = WO(:,H);
    E =  PYPi-WOH;
    EV = sqrt(sum(E.*E, 1) + eps);
    tD{v} = diag(0.5./EV*(beta(v)^gamma));
end