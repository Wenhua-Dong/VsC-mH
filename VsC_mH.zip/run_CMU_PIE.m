clear; close all; clc;

addpath([pwd, '/Data']);
addpath([pwd, '/Evaluation']);

% load data
load CMU_PIE_2views.mat

nv = length(Y);
n = size(Y{1},2);
k = length(unique(gt));
r = k;        % Dimension of the latent space
nrp = 10;     % The number of repetitions

% Parameter settings
gamma = 7;

% Shuffle the data
alpha = 0;         % Alignment ratio
na = round(alpha*n);
it = 2;              % The index of the template
if na<n
    [dat,gnd] = shuffle_data(Y,gt,na,it);
else
    dat = Y;
    gnd = gt;
end
% Normalization
ndat = cell(1,nv);
for v = 1:nv
    ndatt = zscore(dat{v}');
    ndat{v} = ndatt';
end

% Run VsC-mH
results = zeros(nrp,3);
for i = 1:nrp
    tic;
    H = VsC_mH(ndat, k, r, na, gamma, it);
    ctime = toc;
    results(i,:) = per_eva(H, gnd);
    fprintf('\n result: %d-th, ACC: %.4f, NMI: %.4f, F: %.4f', i, results(i,1), results(i,2), results(i,3))
    clear H
end
mresult = mean(results);
fprintf('\n mresult: ACC: %.4f, NMI: %.4f, F: %.4f', mresult(1), mresult(2), mresult(3));
