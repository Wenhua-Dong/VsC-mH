function [ O ] = solve_O(P, Y, Pi0, W, H, tD, k)

nv = length(Y);
n = size(Y{1},2);
O = cell(1,nv);

for v=1:nv
    HtDH_vec = zeros(1,k);
    for i=1:n
        HtDH_vec(H(i)) = HtDH_vec(H(i)) + tD{v}(i,i);
    end
    HtDH_invec = 1./(HtDH_vec+eps);

    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    tD{v} = full(tD{v});
    PYPiD = PYPi*tD{v};
    PYPiDH = zeros(size(PYPiD,1),k);
    for j = 1:k
        PYPiDH(:,j) = sum(PYPiD(:,find(H==j)), 2);
    end
    tmp = PYPiDH.*repmat(HtDH_invec, size(PYPiDH,1), 1);
    O{v} = W'*tmp;
end
end