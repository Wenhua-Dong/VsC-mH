
function [ beta ] = solve_beta(P, Y, Pi0, W, O, H, gamma)
% 
nv = length(Y);
error = zeros(nv, 1);
temp = 1/(1-gamma);

for v=1:nv    
    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    WO = W*O{v};
    WOH = WO(:,H);
    E = PYPi-WOH;
    E21 = sum(sqrt(sum(E.*E, 1) + eps));
    error(v) = E21^temp;
end
beta = error./sum(error);
end
