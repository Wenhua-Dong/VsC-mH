function [ H ] = solve_H(P, Y, Pi0, W, O, tD, it)

nv = length(Y);
n = size(Y{1}, 2);
indv = zeros(n,nv);
H = zeros(n,1);
Ds = 0;

for v = 1:nv
    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    WO = W*O{v};    
    Dv = EuDist2(PYPi',WO',0);
    [~,indv(:,v)] = min(Dv,[],2);
    tD{v} = full(tD{v});
    Ds = Ds+tD{v}*Dv;
end
Ds = Ds./repmat(sqrt(sum(Ds.^2,1)),n,1);

for i = 1:n
    if indv(i,:)==indv(i,it)
        H(i) = indv(i,it);
    else
        [~, H(i)] = min(Ds(i,:),[],2);
    end
end