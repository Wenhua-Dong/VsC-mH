function [ objs ] = cal_obj(P, Y, Pi0, W, O, H, tD)

nv = length(Y);
objs = 0;

for v=1:nv
    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    WO = W*O{v};
    WOH = WO(:,H);    
    E = PYPi-WOH;
    tD{v} = full(tD{v});
    objs = objs+sum(diag(E*tD{v}*E'));
end
end