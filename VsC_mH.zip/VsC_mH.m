function [H] = VsC_mH(Y, k, r, na, gamma, it)

% Objective function of VsC-mH: 
% min sum_{v=1}^{nv} beta_{v}^gamma*||PvYvPiv-WOvH^{T}||_2,1, 
% s.t. PvPv^{T} = I, W^{T}W = I, sum_{v=1}^{nv} beta_{v} = 1.
% Remark: Please remove the seed of the random number stream in VsC_mH, 
% lines 21-22 for verification results.

nv = length(Y);
n = size(Y{1}, 2);
c = k;
iters = 60; 

% initialization
Pi0 = repmat({(1:n)'},1,nv);
W = zeros(r,c);
O = repmat({zeros(c,k)},1,nv);
beta = ones(nv,1)./nv;
P = cell(1,nv); tD = cell(1,nv); 

% s = RandStream('mrg32k3a','Seed',0);
% RandStream.setGlobalStream(s);
H = randi([1,k],n,1);
for v=1:nv
    P{v} = rand(r,size(Y{v},1));      
    if na<n && v ~= it
        Pi0{v}(na+1:n) = na+randperm(n-na)';
    end
    tD{v} = sparse(diag(ones(n, 1))* beta(v)^gamma);
end

obj_value = zeros(1,60);
for j = 1:iters
    % calculate the objective function value
    [ obj_value(j) ] = cal_obj(P, Y, Pi0, W, O, H, tD);
    % update Projection matrix P
    [ P ] = solve_P(Y, Pi0, W, O, H, tD);
    % update base matrix
    [ W ] = solve_W(P, Y, Pi0, O, H, tD);
    % update centroid matrix
    [ O ] = solve_O(P, Y, Pi0, W, H, tD, k);
    % update hard paritition
    [ H ] = solve_H(P, Y, Pi0, W, O, tD, it);
    % update permutation matrix
    [ Pi ] = solve_Pi(P, Y, Pi0, W, O, H, k, na, it, j);
    Pi0 = Pi;
    % update weight
    [ beta ] = solve_beta(P, Y, Pi0, W, O, H, gamma);
    % update tD
    [tD] = solve_tD(P, Y, Pi0, W, O, H, beta, gamma);

    if j>2 && abs(obj_value(j)-obj_value(j-1))/obj_value(j) < 1e-6
        break;
    end
end

end

