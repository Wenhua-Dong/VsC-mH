function [ Pi ] = solve_Pi(P, Y, Pi0, W, O, H, k, na, it, niter)

nv = length(Y);
n = size(Y{1},2);
Pi = repmat({(1:n)'},1,nv);

if na<n
    H2it = H(na+1:n);                    % Partition of the template
    kn = 10;                             % The number of neighbours
    PY2it = P{it}*Y{it}(:,na+1:n); 
    mWOit = mean(W*O{it},2);             % The center of the template in the latent space
    [~,ind2it] = sort(EuDist2(PY2it',mWOit',0));

    for v=1:nv
        if v ~= it
            ns = n-na;                   % The number of the shuffled samples  
            % Calculate the inverse permutation matrix
            temp1 = Pi0;
            temp2 = temp1{v}(na+1:n)-na; 
            Pi02m = zeros(ns); 
            for i = 1:ns
                Pi02m(temp2(i), i) = 1;
            end
            Pi02mt = Pi02m';
            % Convert the inverse permutation into the vector
            [~,ind] = max(Pi02mt,[],1);            
            temp1{v}(na+1:n) = ind+na;
            Hv = H(temp1{v});            

            H2v = Hv(na+1:n);            % Partition of the shuffled part
            PY2v = P{v}*Y{v}(:,na+1:n);
            mWOv = mean(W*O{v},2);
            [~,ind2v] = sort(EuDist2(PY2v',mWOv'));
            Pi2v = zeros(n-na,1);
            % Global alignment
            if mod(niter,2) ~= 0
                Pi2v(ind2it) = ind2v;     
            else
            % Intra-category alignment
                for i = 1:k
                    ind2iti = find(H2it==i); % index of the i-th cluster from the template
                    ni = length(ind2iti);
                    D = zeros(ni);
                    if ~isempty(ind2iti)
                        ind2vi = find(H2v==i);
                        % Construct the cost matrix of the Hungarian algorithm
                        Di = EuDist2(PY2it(:,ind2iti)', PY2v(:,ind2vi)', 0);
                        mDi = max(max(Di))*1000;
                        if ni<10
                            D = Di;  
                            [indi,~] = hungarian(D); 
                        else
                            % Construct the improved cost matrix of the Hungarian algorithm
                            [sDi, sDind] = sort(Di,2);
                            for j = 1:ni
                                D(j,sDind(j,1:kn)) = sDi(j,1:kn);
                                D(j,sDind(j,kn+1:ni)) = mDi;                                
                            end
                            [indi,~] = hungarian(D); 
                        end
                        indvi = zeros(ni,1);
                        indvi(indi) = ind2vi;
                        Pi2v(ind2iti) = indvi; % Alignment
                    end
                end
            end
            Pi{v}(na+1:n) = Pi2v+na;
        end
    end
end