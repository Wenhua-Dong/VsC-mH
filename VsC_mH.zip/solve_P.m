function [ P ] = solve_P(Y, Pi0, W, O, H, tD)

nv = length(Y);
P = cell(1, nv);

for v=1:nv    
    YPi = Y{v}(:,Pi0{v});
    WO = W*O{v};
    WOH = WO(:,H);
    tD{v} = full(tD{v});
    temp = YPi*tD{v}*WOH';
    [U,~,V] = svd(temp, 'econ');
    PT = U*V';
    P{v} = PT';
end
end