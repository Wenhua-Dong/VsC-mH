function [dat,gnd] = shuffle_data(Y,gt,na,it)

nv = length(Y);
n = size(Y{1},2);
index = 1:n;             % Index of original samples
aindex = randperm(n,na); % Index of the aligned smples
index(aindex) = [];      % Index of the remaining samples
indall = cell(1,nv);     % Index of view-shuffled data
dat = cell(1,nv);        % Shuffled data
for v=1:nv
    indall{v} = [];
    indall{v} = [indall{v} aindex];
    tmp = randperm(n-na);
    sindex = index(tmp); % Index of shuffled samples
    indall{v} = [indall{v} sindex];
    dat{v} = Y{v}(:,indall{v});
    clear tmp sindex
end
gnd = gt(indall{it});    % ground-truth of the anchor view
end