function [ W ] = solve_W(P, Y, Pi0, O, H, tD)

nv = length(Y);
[c, k] = size(O{1});
temp = 0; 
for v=1:nv
    PY = P{v}*Y{v};
    PYPi = PY(:,Pi0{v});
    tD{v} = full(tD{v});
    DPYPit = tD{v}*PYPi';    
    HtDPYPit = zeros(k, size(DPYPit,2));
    for i = 1:k
        HtDPYPit(i,:) = sum(DPYPit(find(H==i),:), 1)+eps;
    end
    temp = temp + O{v}*HtDPYPit;
end
[U,~,V] = svds(temp, c);
WT = U*V';
W = WT';
end